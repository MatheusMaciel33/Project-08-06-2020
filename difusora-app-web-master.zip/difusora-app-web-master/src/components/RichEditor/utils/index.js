import { setBlockData, blockRenderMap } from './block';

export { setBlockData, blockRenderMap };
