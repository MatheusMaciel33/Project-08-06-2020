export { default } from './PlaceManagentList';
