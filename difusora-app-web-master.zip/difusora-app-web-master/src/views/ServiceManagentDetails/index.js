export { default } from './ServiceManagentDetails';
