export { default } from './StoreManagentDetails';
