export { default } from './ServiceManagentList';
