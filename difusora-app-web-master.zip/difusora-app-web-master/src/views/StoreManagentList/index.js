export { default } from './StoreManagentList';
