export { default } from './CouponManagentList';
