export { default } from './CalendarManagentDetails';
