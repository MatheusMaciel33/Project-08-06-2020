export { default } from './CouponManagentDetails';
