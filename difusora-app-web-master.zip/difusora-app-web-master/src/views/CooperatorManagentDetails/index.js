export { default } from './CooperatorManagentDetails';
