export { default } from './PlaceManagentDetails';
